********************************************************************
	CYBERISM�global - HTTP://WWW.CYBERNEWS.COM
	   RESOURCES FOR WEBMASTERS
********************************************************************

This is a free web resources by Cyberism�global (http://www.cybenews.com)



1. Customizing
-----------------------------------------
To change the text, content, links etc. open the index.html in your preferred HTML editor, whether it be notepad, dreamweaver or frontpage.

To change the CSS open styles.css in a HTML/CSS editor and change the appropriate values to suit your needs.


2. Terms of use/License
-----------------------------------------
This content has been released under a Creative Commons Attribution license, this means you can use this as long as a visible link to Cyberism�(http://www.cybernews.com) remains in the footer.
 
This condition can be waived by purchasing a  license for �8.00 (See 3. Template License in this document)

For more information of the license: http://creativecommons.org/licenses/by/3.0/


3. Template License
-----------------------------------------
The link back to Cyberism� (http://www.cybernews.com) and any other copyright/information relating to Cyberism�(http://www.cybernews.com) can be removed with the purchase of a  license. A license costs �8.00 (Approx $12USD) per template per site and gives the site owner/webmaster the right to remove this information.

To purchase a license or for more information see: http://cybernews.com/licensing


4. Other information
-----------------------------------------
Please contact us if you need more information about the licences, use of our templates or other queries -  http://www.cybernews.com/contact
